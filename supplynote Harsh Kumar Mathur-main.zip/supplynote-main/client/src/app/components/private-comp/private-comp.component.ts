import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-comp',
  templateUrl: './private-comp.component.html',
  styleUrls: ['./private-comp.component.css']
})
export class PrivateCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
