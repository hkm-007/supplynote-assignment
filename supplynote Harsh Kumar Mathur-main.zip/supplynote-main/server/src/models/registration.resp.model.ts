export class RegistrationRespModel {
  successStatus: boolean;
  message: string;
}
